# discord-tutorial-bot
Tutorial bot

Discord tutorial bot from Snowflake Studio ❄
